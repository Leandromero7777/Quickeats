<?php
require_once __DIR__ . '/includes/auth.php';

// Vaciar los datos de la sesion.
$_SESSION = [];

// Eliminar la cookie de sesion usando un timestamp entero (PHP 7/8).
if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params['path'] ?: '/',
        $params['domain'],
        $params['secure'],
        $params['httponly']
    );
}

session_destroy();
header('Location: index.php');
exit;
