<?php 
require_once 'includes/auth.php';
if (!empty($_SESSION['usuario_id'])) redirectByRole();
?>
<!doctype html>
<html lang="es">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <title>QuickEats - Iniciar sesión</title>
        <link rel="icon" href="img/Quick1.png">
        <link rel="stylesheet" href="css/style.css">
        <link href="https://fonts.googleapis.com/css2?family=Amatic+SC:wght@400;700&display=swap" rel="stylesheet">
    </head>
        <body>
            <div class="contenedor">
            <div class="izquierda">
                <img src="img/Quick.png" class="logo" alt="QuickEats">
            </div>
                <div class="derecha">
                    <h2>Iniciar Sesión</h2>
                    <form method="post" action="api/login.php">
                        <input name="usuario" type="text" placeholder="Usuario" required autofocus>
                        <input name="contra" type="password" placeholder="Contraseña" required>
                        <button type="submit">Ingresar</button>
                        <a class="secondary-btn" href="crear.html">Crear cuenta</a>
                    </form>
                </div>
            </div>
        </body>
        </html>
