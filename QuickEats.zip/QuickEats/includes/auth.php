<?php
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
function requireLogin(): void { if (empty($_SESSION['usuario_id'])) { $dir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')); $prefix = preg_match('#/(admin|cliente|cocina|api)$#', $dir) ? '../' : ''; header('Location: ' . $prefix . 'index.php'); exit; } }
function requireRole(string ...$roles): void { requireLogin(); if (!in_array($_SESSION['cargo'] ?? '', $roles, true)) { http_response_code(403); exit('Acceso no autorizado.'); } }
function redirectByRole(): void {
    $script = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '/index.php');
    $dir = dirname($script);
    // Si se llama desde /api/login.php, subir un nivel extra hasta la raíz del proyecto.
    if (basename($dir) === 'api') { $dir = dirname($dir); }
    $base = rtrim($dir, '/');
    if ($base === '.' || $base === '/') { $base = ''; }
    $role = $_SESSION['cargo'] ?? '';
    if ($role === 'admin') { $target = '/admin/index.php'; }
    elseif ($role === 'cocina') { $target = '/cocina/index.php'; }
    else { $target = '/cliente/index.php'; }
    header('Location: ' . $base . $target);
    exit;
}
function e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function money($v): string { return '$ '.number_format((float)$v, 2, ',', '.'); }
