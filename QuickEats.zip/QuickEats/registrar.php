<?php require_once 'conexion.php';
if($_SERVER['REQUEST_METHOD']!=='POST'){header('Location: crear.html');exit;}
$u=trim($_POST['usuario']??'');$c=trim($_POST['contacto']??'');$d=trim($_POST['direccion']??'');$p=$_POST['contra']??'';$tipo=$_POST['tipoContacto']??'';
if($u===''||$c===''||$d===''||$p===''||!in_array($tipo,['mail','telefono'],true)){exit('Complete correctamente todos los campos. <a href="crear.html">Volver</a>');}
if($tipo==='mail' && !filter_var($c,FILTER_VALIDATE_EMAIL)){exit('El mail no es válido. <a href="crear.html">Volver</a>');}
if($tipo==='telefono' && !preg_match('/^[0-9 +()-]{7,20}$/',$c)){exit('El teléfono no es válido. <a href="crear.html">Volver</a>');}
$s=$conexion->prepare('SELECT id FROM usuarios WHERE usuario=?');$s->bind_param('s',$u);$s->execute();if($s->get_result()->num_rows){exit('Ese usuario ya existe. <a href="crear.html">Volver</a>');}
$h=password_hash($p,PASSWORD_DEFAULT);$cargo='cliente';$s=$conexion->prepare('INSERT INTO usuarios(usuario,contra,cargo,contacto,direccion) VALUES(?,?,?,?,?)');$s->bind_param('sssss',$u,$h,$cargo,$c,$d);$s->execute();header('Location: index.php?created=1'); exit;
