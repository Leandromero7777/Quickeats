<?php
require_once __DIR__ . '/../conexion.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole('cliente');
header('Content-Type: application/json; charset=utf-8');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo json_encode(['ok'=>false,'message'=>'Método no permitido.']); exit; }
$raw = file_get_contents('php://input');
$data = json_decode($raw, true);
if (!is_array($data)) { $data = $_POST; }
$items = $data['items'] ?? null;
// Compatibilidad con el formulario antiguo de un solo producto.
if (!is_array($items) && isset($data['vianda_id'])) { $items = [['vianda_id'=>$data['vianda_id'],'cantidad'=>$data['cantidad'] ?? 1]]; }
if (!is_array($items) || count($items) === 0) { http_response_code(400); echo json_encode(['ok'=>false,'message'=>'El carrito está vacío.']); exit; }
$normalizados = [];
foreach ($items as $item) {
    $id = filter_var($item['vianda_id'] ?? $item['id'] ?? null, FILTER_VALIDATE_INT);
    $cantidad = filter_var($item['cantidad'] ?? 0, FILTER_VALIDATE_INT);
    if (!$id || !$cantidad || $cantidad < 1 || $cantidad > 99) { http_response_code(400); echo json_encode(['ok'=>false,'message'=>'Hay una vianda o cantidad inválida.']); exit; }
    $normalizados[$id] = ($normalizados[$id] ?? 0) + $cantidad;
}
try {
    $conexion->begin_transaction();
    $total = 0.0; $detalles = [];
    $consulta = $conexion->prepare('SELECT id,nombre,precio FROM viandas WHERE id=? LIMIT 1');
    foreach ($normalizados as $id => $cantidad) {
        $consulta->bind_param('i', $id); $consulta->execute(); $v = $consulta->get_result()->fetch_assoc();
        if (!$v) { throw new RuntimeException('Una de las viandas ya no está disponible. Actualizá el menú e intentá de nuevo.'); }
        $precio = (float)$v['precio']; $total += $precio * $cantidad;
        $detalles[] = ['id'=>(int)$v['id'],'nombre'=>$v['nombre'],'cantidad'=>$cantidad,'precio'=>$precio];
    }
    $estado = 'pendiente';
    $insertar = $conexion->prepare('INSERT INTO pedidos(usuario_id,estado,total,fecha) VALUES(?,?,?,NOW())');
    $insertar->bind_param('isd', $_SESSION['usuario_id'], $estado, $total); $insertar->execute();
    $pedidoId = $conexion->insert_id;
    $detalle = $conexion->prepare('INSERT INTO pedido_detalle(pedido_id,vianda_id,cantidad,precio_unitario) VALUES(?,?,?,?)');
    foreach ($detalles as $d) { $detalle->bind_param('iiid', $pedidoId, $d['id'], $d['cantidad'], $d['precio']); $detalle->execute(); }
    $conexion->commit();
    echo json_encode(['ok'=>true,'message'=>'Pedido #'.$pedidoId.' creado correctamente','pedido_id'=>$pedidoId,'total'=>$total,'items'=>$detalles], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    try { $conexion->rollback(); } catch (Throwable $ignored) {}
    http_response_code(400);
    echo json_encode(['ok'=>false,'message'=>$e instanceof RuntimeException ? $e->getMessage() : 'No se pudo guardar el pedido. Revisá la conexión y las tablas existentes.'], JSON_UNESCAPED_UNICODE);
}
