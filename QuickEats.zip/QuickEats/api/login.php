<?php
require_once '../conexion.php'; require_once '../includes/auth.php';
if($_SERVER['REQUEST_METHOD']!=='POST'){header('Location: ../index.php');exit;}
$u=trim($_POST['usuario']??''); $p=$_POST['contra']??'';
$stmt=$conexion->prepare('SELECT id,usuario,contra,cargo FROM usuarios WHERE usuario=? LIMIT 1'); $stmt->bind_param('s',$u); $stmt->execute(); $r=$stmt->get_result(); $row=$r->fetch_assoc();
if(!$row){ header('Location: ../index.php?error=1'); exit; }
$ok=password_verify($p,$row['contra']) || hash_equals((string)$row['contra'],$p);
if(!$ok){header('Location: ../index.php?error=1');exit;}
if(strlen($row['contra'])<60 || !password_get_info($row['contra'])['algo']) { $h=password_hash($p,PASSWORD_DEFAULT); $s=$conexion->prepare('UPDATE usuarios SET contra=? WHERE id=?'); $s->bind_param('si',$h,$row['id']);$s->execute(); }
session_regenerate_id(true); $_SESSION['usuario_id']=$row['id'];$_SESSION['usuario']=$row['usuario'];$_SESSION['cargo']=$row['cargo']; redirectByRole();
