<?php 
require_once '../conexion.php';
require_once '../includes/auth.php';
requireRole('cliente');
header('Content-Type: application/json');
$v=(int)($_POST['vianda_id']??0);
$u=$_SESSION['usuario_id'];
$s=$conexion->prepare('SELECT id FROM favoritos WHERE usuario_id=? AND vianda_id=?');
$s->bind_param('ii',$u,$v);
$s->execute();
$exists=$s->get_result()->num_rows>0;
if($exists){$s=$conexion->prepare('DELETE FROM favoritos WHERE usuario_id=? AND vianda_id=?');
$s->bind_param('ii',$u,$v);
$s->execute();
$fav=false;
}else{
    $s=$conexion->prepare('INSERT INTO favoritos(usuario_id,vianda_id) VALUES(?,?)');
    $s->bind_param('ii',$u,$v);
    $s->execute();
    $fav=true;
    }
    echo json_encode(['ok'=>true,'favorito'=>$fav]);
