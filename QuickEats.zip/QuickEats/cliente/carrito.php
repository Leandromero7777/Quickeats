<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole('cliente');
require_once __DIR__ . '/../conexion.php';
require_once __DIR__ . '/../includes/layout.php';
clientHeader('Carrito', 'orders');
?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">
  <h1 class="page-title mb-0">Mi carrito</h1>
  <a class="btn btn-outline-warning" href="index.php">← Seguir eligiendo viandas</a>
</div>
<div id="carritoContenido"><div class="empty">Cargando carrito...</div></div>
<div id="carritoMensaje" class="mt-3" role="status"></div>
<div class="d-flex flex-wrap gap-2 mt-4">
  <button id="vaciarCarrito" class="btn btn-outline-danger">Vaciar carrito</button>
  <button id="confirmarPedido" class="btn btn-warning">Confirmar pedido</button>
  <a href="pedidos.php" class="btn btn-outline-secondary">Ver mis pedidos</a>
</div>
<script>
const CONTEXTO_CARRITO = { api: '../api/pedido.php' };
</script>
<script src="../js/carrito.js"></script>
<?php clientFooter(); ?>
