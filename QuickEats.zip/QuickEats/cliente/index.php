<?php 
require_once __DIR__ . '/../includes/auth.php';  
requireRole('cliente'); 
require_once '../conexion.php';
require_once '../includes/layout.php'; 
clientHeader('Viandas Menu','home');
$res=$conexion->query('SELECT id,nombre,imagen,tipo,precio FROM viandas ORDER BY id DESC');
$viandas=$res->fetch_all(MYSQLI_ASSOC);
$f=$conexion->prepare('SELECT vianda_id FROM favoritos WHERE usuario_id=?');
$f->bind_param('i',$_SESSION['usuario_id']);
$f->execute();
$fav=[];
foreach($f->get_result() as $x)$fav[]=(int)$x['vianda_id']; 
?>
<header class="d-flex gap-3 mb-4">
    <div class="search-box flex-grow-1 d-flex align-items-center px-3">
        <span class="fs-4">🔍</span>
        <input type="text" id="buscador" class="form-control border-0 shadow-none" placeholder="Search">
    </div>
    <button class="btn filter-btn px-4" type="button" data-bs-toggle="offcanvas" data-bs-target="#filtros">⚙ Filter</button>
</header>
<h1 class="mb-4">Viandas Menu</h1>
<section id="menuViandas" class="row g-4"></section>
<button id="btnMore" class="btn more-btn d-block mx-auto mt-4">More</button>
<div class="offcanvas offcanvas-end" tabindex="-1" id="filtros">
    <div class="offcanvas-header">
        <h5 class="offcanvas-title">Filtrar viandas</h5>
        <button class="btn-close" data-bs-dismiss="offcanvas"></button>
    </div>
    <div class="offcanvas-body">
        <label class="form-label">Tipo de comida</label>
        <select id="filtroTipo" class="form-select">
            <option value="todos">Todas</option>
            <option value="carne">Carne</option>
            <option value="pollo">Pollo</option>
            <option value="vegetariano">Vegetariano</option>
            <option value="pescado">Pescado</option>
        </select>
        <label class="form-label mt-3">Precio máximo</label>
        <input id="filtroPrecio" class="form-control" type="number" min="0" placeholder="Sin límite">
        <button id="aplicarFiltro" class="btn btn-warning w-100 mt-3">Aplicar filtros</button>
    </div>
</div>
<script>const VIANDAS=<?=json_encode($viandas,JSON_UNESCAPED_UNICODE)?>;const FAVORITOS=<?=json_encode($fav)?>;
</script>
<script src="../js/cliente.js"></script>
<?php 
clientFooter(); 
?>
