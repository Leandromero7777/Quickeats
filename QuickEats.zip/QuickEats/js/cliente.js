let lista=VIANDAS, cantidadMostrar=6;
const menu=document.getElementById('menuViandas'),buscador=document.getElementById('buscador'),btnMore=document.getElementById('btnMore');
let tipo='todos',precio='';
function render(){let q=buscador.value.toLowerCase().trim();let filtrada=lista.filter(v=>(!q||v.nombre.toLowerCase().includes(q)||v.tipo.toLowerCase().includes(q))&&(tipo==='todos'||v.tipo.toLowerCase()===tipo)&&(!precio||Number(v.precio)<=Number(precio)));
    menu.innerHTML='';
    filtrada.slice(0,cantidadMostrar).forEach(v=>{let col=document.createElement('div');
        col.className='col-12 col-md-6 col-lg-4';
        let fav=FAVORITOS.includes(Number(v.id));
        col.innerHTML=`
            <div class="vianda-card h-100">
            <button class="favorite" type="button">
            <img src="../img/${fav?'corazonlleno.png':'corazon.png'}" class="corazon" width="25" height="25"></button>
            <div class="imagen-container">
            <img src="../${v.imagen}" alt="${v.nombre}"></div>
            <h2 class="food-title text-center">${v.nombre}</h2>
            <p class="tipo text-center">${v.tipo}</p>
            <p class="precio text-center">$ ${Number(v.precio).toFixed(2)}</p>
            <div class="card-actions">
            <button class="order-btn pedir">Agregar al carrito</button>
            </div>
            </div>`;
            col.querySelector('.favorite').onclick=async()=>{let r=await fetch('../api/favorito.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'vianda_id='+v.id});
            let d=await r.json();
            if(d.ok){if(d.favorito){
                FAVORITOS.push(Number(v.id));
            }else{
                FAVORITOS.splice(FAVORITOS.indexOf(Number(v.id)),1)}render()}};
                col.querySelector('.pedir').onclick=()=>{let carrito=JSON.parse(localStorage.getItem('quickeats_carrito')||'{}');
                    let id=String(v.id);
                    if(!carrito[id])carrito[id]={id:Number(v.id),nombre:v.nombre,imagen:v.imagen,precio:Number(v.precio),cantidad:0};
                    carrito[id].cantidad++;
                    localStorage.setItem('quickeats_carrito',JSON.stringify(carrito));
                    alert(v.nombre+' agregado al carrito.');
                };
                menu.appendChild(col)});
                btnMore.style.display=filtrada.length>cantidadMostrar?'block':'none';
                if(!filtrada.length)menu.innerHTML='<div class="col-12"><div class="empty">No se encontraron viandas.</div></div>'}
                buscador.oninput=()=>{cantidadMostrar=6;render()};
                btnMore.onclick=()=>{cantidadMostrar+=2;render()};
                document.getElementById('aplicarFiltro').onclick=()=>{tipo=document.getElementById('filtroTipo').value;
                    precio=document.getElementById('filtroPrecio').value;
                    cantidadMostrar=6;
                    render();
                    bootstrap.Offcanvas.getInstance(document.getElementById('filtros')).hide()};
                    render();
