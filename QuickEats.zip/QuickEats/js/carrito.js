(() => {
  const KEY = 'quickeats_carrito';
  const cont = document.getElementById('carritoContenido');
  const msg = document.getElementById('carritoMensaje');
  const confirmar = document.getElementById('confirmarPedido');
  const vaciar = document.getElementById('vaciarCarrito');
  let enviando = false;
  const leer = () => { try { return JSON.parse(localStorage.getItem(KEY) || '{}'); } catch { return {}; } };
  const guardar = c => localStorage.setItem(KEY, JSON.stringify(c));
  const escapar = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const dinero = n => '$ ' + Number(n).toLocaleString('es-UY',{minimumFractionDigits:2,maximumFractionDigits:2});
  function render() {
    const c = leer(); const items = Object.values(c).filter(x => Number(x.cantidad) > 0);
    if (!items.length) { cont.innerHTML = '<div class="empty">Tu carrito está vacío. Agregá viandas desde el menú.</div>'; confirmar.disabled = true; vaciar.disabled = true; return; }
    confirmar.disabled = false; vaciar.disabled = false;
    let total = 0;
    cont.innerHTML = '<div class="table-responsive"><table class="table align-middle"><thead><tr><th>Vianda</th><th>Precio</th><th style="min-width:150px">Cantidad</th><th>Subtotal</th><th></th></tr></thead><tbody>' + items.map(x => {
      const sub = Number(x.precio) * Number(x.cantidad); total += sub;
      return `<tr><td><strong>${escapar(x.nombre)}</strong></td><td>${dinero(x.precio)}</td><td><div class="d-flex align-items-center gap-2"><button class="btn btn-sm btn-outline-secondary" data-act="menos" data-id="${Number(x.id)}" aria-label="Disminuir">−</button><span>${Number(x.cantidad)}</span><button class="btn btn-sm btn-outline-secondary" data-act="mas" data-id="${Number(x.id)}" aria-label="Aumentar">+</button></div></td><td>${dinero(sub)}</td><td><button class="btn btn-sm btn-outline-danger" data-act="quitar" data-id="${Number(x.id)}">Eliminar</button></td></tr>`;
    }).join('') + `</tbody><tfoot><tr><th colspan="3" class="text-end">Total</th><th>${dinero(total)}</th><th></th></tr></tfoot></table></div>`;
  }
  cont.addEventListener('click', e => {
    const b = e.target.closest('button[data-act]'); if (!b) return;
    const c = leer(), id = b.dataset.id; if (!c[id]) return;
    if (b.dataset.act === 'mas') c[id].cantidad++;
    if (b.dataset.act === 'menos') c[id].cantidad--;
    if (b.dataset.act === 'quitar' || c[id].cantidad <= 0) delete c[id];
    guardar(c); render();
  });
  vaciar.addEventListener('click', () => { guardar({}); msg.textContent=''; render(); });
  confirmar.addEventListener('click', async () => {
    if (enviando) return;
    const items = Object.values(leer()).filter(x => Number(x.cantidad) > 0).map(x => ({vianda_id:Number(x.id),cantidad:Number(x.cantidad)}));
    if (!items.length) return;
    enviando = true; confirmar.disabled = true; msg.className='alert alert-info mt-3'; msg.textContent='Registrando tu pedido…';
    try {
      const response = await fetch(CONTEXTO_CARRITO.api, {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({items})});
      const data = await response.json();
      if (!response.ok || !data.ok) throw new Error(data.message || 'No se pudo registrar el pedido.');
      guardar({}); render(); msg.className='alert alert-success mt-3'; msg.textContent = `${data.message} Total: ${dinero(data.total)}.`;
    } catch (err) { msg.className='alert alert-danger mt-3'; msg.textContent=err.message || 'Error al confirmar el pedido.'; }
    finally { enviando = false; confirmar.disabled = Object.keys(leer()).length === 0; }
  });
  render();
})();
